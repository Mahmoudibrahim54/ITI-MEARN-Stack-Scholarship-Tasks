// import { Rectangle, Square } from './Shapes.js'


// var r1 = new Rectangle(3, 4);
// console.log(r1.getArea()); // 12
// console.log(r1.getPerimeter()); // 14
// var r2 = new Rectangle(2, 2);


// var r3 = new Square(3);
// console.log(r3.getArea()); // 9
// console.log(r3.getPerimeter()); // 12
// var r4 = new Square(5);


// console.log(Rectangle.getCount()); // 2


