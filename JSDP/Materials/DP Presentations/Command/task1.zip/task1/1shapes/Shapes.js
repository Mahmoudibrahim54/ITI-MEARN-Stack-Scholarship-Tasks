
export function Rectangle(_width, _height) {
  if (this.constructor == Rectangle) {
    Rectangle[count] += 1;
  }

  this.width = _width;
  this.height = _height;
  this.getArea = function () {
    return this.width * this.height;
  }
  this.getPerimeter = function () {
    return (this.width + this.height) * 2;
  }
}

var count = Symbol('count');
Rectangle[count] = 0;

Rectangle.getCount = function () {
  return Rectangle[count];
}


export function Square(_length) {
  Rectangle.call(this, _length, _length);
}
