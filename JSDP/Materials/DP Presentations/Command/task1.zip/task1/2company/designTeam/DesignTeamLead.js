export class DesignTeamLead {
  constructor(_name, _id) {
    if (DesignTeamLead[teamLeader]) {
      return DesignTeamLead[teamLeader];
    }
    this.name = _name;
    this.id = _id;
  }
}

var teamLeader = Symbol('DesignTeamLeader');

// Whenever the user tries to get the team leader, he gets the following leader
var designTeamLeader = new DesignTeamLead("Designoooo", "DS99");
DesignTeamLead[teamLeader] = designTeamLeader;
