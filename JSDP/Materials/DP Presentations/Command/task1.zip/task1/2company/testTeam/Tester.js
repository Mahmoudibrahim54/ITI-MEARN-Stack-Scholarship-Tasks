import { Employee } from '../Employee.js'
import { TestTeamLead } from './TestTeamLead.js'

export class Tester extends Employee {
  constructor(_name, _age, _salary, _framework) {
    super(_name, _age, _salary);
    this.framework = _framework;

  }


  get teamLeader() {
    // Always get the last version of the team leader
    return new TestTeamLead();
  }

  set teamLeader(val) {
    throw new TypeError('Can\'t change test team leader from team member!');
  }

  toString() {
    return super.toString() + ` I am a tester and my favourite framework is ${this.framework}.`
  }
}