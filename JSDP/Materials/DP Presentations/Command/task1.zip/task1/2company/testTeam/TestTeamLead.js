export class TestTeamLead {
  constructor(_name, _id) {
    if (TestTeamLead[teamLeader]) {
      return TestTeamLead[teamLeader];
    }
    this.name = _name;
    this.id = _id;
  }
}


let teamLeader = Symbol('TestTeamLeader');


// Whenever the user tries to get the team leader, he gets the following leader
let testTeamLeader = new TestTeamLead("Testooo", "T99");
TestTeamLead[teamLeader] = testTeamLeader;
