import { Developer } from './devTeam/Developer.js';
import { Tester } from './testTeam/Tester.js';
import { Designer } from './designTeam/Designer.js';

export class Company {
  constructor(_name, _CEO) {
    this.name = _name;
    this.CEO = _CEO;
  }

  createEmp(type, ...args) {
    switch (type) {
      case 1:
        return new Developer(...args);
        break;
      case 2:
        return new Tester(...args);
        break;
      case 3:
        return new Designer(...args);
        break;
      default:
        throw new TypeError(`Employee role of ID (${type}) doesn't exist`);
    }
  }
}