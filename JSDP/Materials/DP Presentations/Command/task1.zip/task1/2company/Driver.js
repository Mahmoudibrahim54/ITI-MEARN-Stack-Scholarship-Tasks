// import { Company } from './Company.js';

// // Initialize the company
// let google = new Company('google', 'khaled');

// // Employees array
// var employees = []

// // Create employees from google company
// employees.push(google.createEmp(1, "Ahmed", 35, 300, "JavaScript"));
// employees.push(google.createEmp(2, "Mohamed", 30, 260, "Jest"));
// employees.push(google.createEmp(3, "Hassan", 25, 400, "Photoshop"));
// employees.push(google.createEmp(3, "Alaa", 20, 100, "Illustrator"));

// // Print employee details
// for (let e of employees) {
//   console.log(e.toString());
// }

// // Testing team leader for 2 development members
// var developer1 = google.createEmp(1, "Ahmed", 35, 300, "JavaScript");
// var developer2 = google.createEmp(1, "Ahmed2", 352, 3002, "JavaScript2");
// console.log(developer1.teamLeader);
// console.log(developer2.teamLeader);

// // Accessing team leader for testing member
// var test1 = google.createEmp(2, "Mohamed", 30, 260, "Jest");
// console.log(test1.teamLeader);

// // Accessing team leader for design member
// var designer2 = google.createEmp(3, "Hassan", 25, 400, "Photoshop");
// console.log(designer2.teamLeader);

// // Changing teamleader from a team member is prohibited
// developer1.teamLeader = "hasdas"
