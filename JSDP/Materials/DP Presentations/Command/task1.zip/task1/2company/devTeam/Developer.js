import { Employee } from '../Employee.js'
import { DevTeamLead } from './DevTeamLead.js'

export class Developer extends Employee {
  constructor(_name, _age, _salary, _language) {
    super(_name, _age, _salary);
    this.language = _language;
  }

  get teamLeader() {
    // Always get the last version of the team leader
    return new DevTeamLead();
  }

  set teamLeader(val) {
    throw new TypeError('Can\'t change developer team leader from team member!');
  }

  toString() {
    return super.toString() + ` I am a developer and my favourite language is ${this.language}.`;
  }
}

