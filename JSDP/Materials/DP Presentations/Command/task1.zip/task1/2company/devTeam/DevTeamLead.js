export class DevTeamLead {
  constructor(_name, _id) {
    if (DevTeamLead[teamLeader]) {
      return DevTeamLead[teamLeader];
    }

    this.name = _name;
    this.id = _id;
  }
}


var teamLeader = Symbol('DevTeamLeader');


// Whenever the user tries to get the team leader, he gets the following leader
var devTeamLeader = new DevTeamLead("Devooooo", "DV10");
DevTeamLead[teamLeader] = devTeamLeader;
