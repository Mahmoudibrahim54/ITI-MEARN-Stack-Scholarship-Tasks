export class Employee {

  constructor(_name, _age, _salary) {
    if (this.constructor == Employee) {
      throw new TypeError('Employee is abstract, can\'t instanciate it.')
    }
    this.name = _name;
    this.age = _age;
    this.salary = _salary;
  }

  toString() {
    return `Hi, I am ${this.name}, ${this.age} years old`
      + `. I get paid ${this.salary}$`
  }
}
